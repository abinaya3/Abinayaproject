package bean;

public class Ticket {
private String thname;
private String thadr;
private String fname;
private String fcert;
private String shdate;
private String shtime;
private String sno1;
private String sno2;
private String sno3;
private String sno4;
private String sno5;
private String sno6;
private String sno7;
private String sno8;
private String sno9;
private String sno10;
private String uname;
private String uaddr;
private String upass;
private String ugender;
private Long uphno;
private String bdate;
private String btime;
private String nost;
private Double shprice;
public String getThname() {
	return thname;
}
public void setThname(String thname) {
	this.thname = thname;
}
public String getThadr() {
	return thadr;
}
public void setThadr(String thadr) {
	this.thadr = thadr;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getFcert() {
	return fcert;
}
public void setFcert(String fcert) {
	this.fcert = fcert;
}
public String getShdate() {
	return shdate;
}
public void setShdate(String shdate) {
	this.shdate = shdate;
}
public String getShtime() {
	return shtime;
}
public void setShtime(String shtime) {
	this.shtime = shtime;
}
public String getSno1() {
	return sno1;
}
public void setSno1(String sno1) {
	this.sno1 = sno1;
}
public String getSno2() {
	return sno2;
}
public void setSno2(String sno2) {
	this.sno2 = sno2;
}
public String getSno3() {
	return sno3;
}
public void setSno3(String sno3) {
	this.sno3 = sno3;
}
public String getSno4() {
	return sno4;
}
public void setSno4(String sno4) {
	this.sno4 = sno4;
}
public String getSno5() {
	return sno5;
}
public void setSno5(String sno5) {
	this.sno5 = sno5;
}
public String getSno6() {
	return sno6;
}
public void setSno6(String sno6) {
	this.sno6 = sno6;
}
public String getSno7() {
	return sno7;
}
public void setSno7(String sno7) {
	this.sno7 = sno7;
}
public String getSno8() {
	return sno8;
}
public void setSno8(String sno8) {
	this.sno8 = sno8;
}
public String getSno9() {
	return sno9;
}
public void setSno9(String sno9) {
	this.sno9 = sno9;
}
public String getSno10() {
	return sno10;
}
public void setSno10(String sno10) {
	this.sno10 = sno10;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getUaddr() {
	return uaddr;
}
public void setUaddr(String uaddr) {
	this.uaddr = uaddr;
}
public String getUpass() {
	return upass;
}
public void setUpass(String upass) {
	this.upass = upass;
}
public String getUgender() {
	return ugender;
}
public void setUgender(String ugender) {
	this.ugender = ugender;
}
public Long getUphno() {
	return uphno;
}
public void setUphno(Long uphno) {
	this.uphno = uphno;
}
public String getBdate() {
	return bdate;
}
public void setBdate(String bdate) {
	this.bdate = bdate;
}
public String getBtime() {
	return btime;
}
public void setBtime(String btime) {
	this.btime = btime;
}
public String getNost() {
	return nost;
}
public void setNost(String nost) {
	this.nost = nost;
}
public Double getShprice() {
	return shprice;
}
public void setShprice(Double shprice) {
	this.shprice = shprice;
}

}
