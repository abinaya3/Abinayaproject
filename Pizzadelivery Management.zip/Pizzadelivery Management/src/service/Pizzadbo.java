package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.Pizzaclass;
import util.Dbutil;

public class Pizzadbo {
   Connection c=null;
   public Pizzadbo() throws ClassNotFoundException, SQLException
   {
	   Dbutil dbu =new Dbutil();
		c=dbu.getDBConn(); 
   }
   public void insertpizza(Pizzaclass pcs) throws SQLException
   {
		  PreparedStatement p=c.prepareStatement("insert into addproduct(pid,pname,ptype,pprice)values(pid.nextval,?,?,?)");
		  p.setString(1,pcs.getPname());
		  p.setString(2,pcs.getPtype());
		  p.setDouble(3,pcs.getPprice());
		  p.execute();
   }
   public void insertcustomer(Pizzaclass pcs) throws SQLException
   {
	   PreparedStatement p=c.prepareStatement("insert into customer(cusid,cusname,cusadr,cuspass,cusgender,cusphno)values(cusid.nextval,?,?,?,?,?)");
	   p.setString(1,pcs.getCusname());
	   p.setString(2,pcs.getCusadr());
	   p.setString(3,pcs.getCuspass());
	   p.setString(4,pcs.getCusgender());
	   p.setLong(5,pcs.getCusphno());
	   p.execute();
   }
   public void insertpizzapurchase(Pizzaclass pcs,int csid1,int pd) throws SQLException
   {
	   PreparedStatement p=c.prepareStatement("insert into pizzapurchase(prid,cusid,pid,quantity,prdate,prtime,prstatus)values(prid.nextval,?,?,?,sysdate,?,?)");
	   p.setInt(1,csid1);
	   p.setInt(2, pd);
	   p.setInt(3,pcs.getQuantity());
	   p.setString(4,pcs.getPrtime());
	   //System.out.println("kl");
	   p.setString(5,pcs.getPrstatus());
	   p.execute();
   }
}
