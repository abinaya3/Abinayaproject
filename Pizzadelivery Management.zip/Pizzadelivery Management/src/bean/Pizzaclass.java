package bean;

public class Pizzaclass {
private String pname;
private String ptype;
private Double pprice;
private String cusname;
private String cusadr;
private String cuspass;
private String cusgender;
private long cusphno;
private int quantity;
private String prdate;
private String prtime;
private String prstatus;
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public String getPtype() {
	return ptype;
}
public void setPtype(String ptype) {
	this.ptype = ptype;
}
public Double getPprice() {
	return pprice;
}
public void setPprice(Double pprice) {
	this.pprice = pprice;
}
public String getCusname() {
	return cusname;
}
public void setCusname(String cusname) {
	this.cusname = cusname;
}
public String getCusadr() {
	return cusadr;
}
public void setCusadr(String cusadr) {
	this.cusadr = cusadr;
}
public String getCuspass() {
	return cuspass;
}
public void setCuspass(String cuspass) {
	this.cuspass = cuspass;
}

public String getCusgender() {
	return cusgender;
}
public void setCusgender(String cusgender) {
	this.cusgender = cusgender;
}
public long getCusphno() {
	return cusphno;
}
public void setCusphno(long cusphno) {
	this.cusphno = cusphno;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public String getPrdate() {
	return prdate;
}
public void setPrdate(String prdate) {
	this.prdate = prdate;
}
public String getPrtime() {
	return prtime;
}
public void setPrtime(String prtime) {
	this.prtime = prtime;
}
public String getPrstatus() {
	return prstatus;
}
public void setPrstatus(String prstatus) {
	this.prstatus = prstatus;
}

}
