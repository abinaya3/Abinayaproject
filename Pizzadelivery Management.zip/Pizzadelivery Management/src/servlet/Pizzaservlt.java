package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Pizzaclass;
import service.Pizzadbo;
import util.Dbutil;

/**
 * Servlet implementation class Pizzaservlt
 */
@WebServlet("/Pizzaservlt")
public class Pizzaservlt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Pizzaservlt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int csid1=0;
		int pd=0;
		String h="o";
		Connection c=null;
		Dbutil dbu=new Dbutil();
		Pizzaclass pcs=new Pizzaclass();
		try {
			c=dbu.getDBConn();
			Pizzadbo dbo=new Pizzadbo();
			if(request.getParameter("cuspr").equals("order"))
			{
			HttpSession ses=request.getSession();
			 csid1=(Integer)ses.getAttribute("cno");
			// System.out.println(csid1);
			String  pn=request.getParameter("pname");
			// System.out.println(pn);
			// q=Integer.parseInt(request.getParameter("quantity"));
			 PreparedStatement p5 = c.prepareStatement("select pid from addproduct where pname='"+pn+"'");
				ResultSet rs5 = p5.executeQuery("select pid from addproduct where pname='"+pn+"'");
				 while (rs5.next()) 
				 	{
					   pd=rs5.getInt(1);
				 	}
				 pcs.setQuantity(Integer.parseInt(request.getParameter("quantity")));
				 pcs.setPrtime(request.getParameter("prtime"));
				 pcs.setPrstatus(h);
				 dbo.insertpizzapurchase(pcs,csid1,pd);
				response.sendRedirect("option.jsp");
		}}
			
			catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		if(request.getParameter("cuspr").equals("cancel"))
		{
			response.sendRedirect("option.jsp");
		} 
		}
		}
	


